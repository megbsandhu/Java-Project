import java.awt.*;
import java.util.*;
import java.awt.event.*;
import javax.swing.*;


public class TennisGame {

    public static void main(String[] args) {
        GameFrame frame = new GameFrame();
    }




}
